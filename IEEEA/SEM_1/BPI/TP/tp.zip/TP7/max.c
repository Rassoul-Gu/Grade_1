/**
 * Auteur : GUEYE NDIAYE Modou
 * Lire un entier sous la forme n1 | n2 | n3 | ... | nk puis calculer et afficher le maximum de ces entiers
 */

/* Appel des bibliothèques */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

/* Déclarations des fonctions et des macros */


/* Fonction principale */
int main(void) {

    printf("%*.*d\n", 5, 2, 1);
    
    
    return EXIT_SUCCESS;
}

/* Définitions des fonctions */