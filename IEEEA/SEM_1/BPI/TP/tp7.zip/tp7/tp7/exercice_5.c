/* [Nom du programme]
 * [Date de Création]
 * [Auteur(s)/Auteure(s)]
 * [Descriptif du programme ]
 */


/* Appel des bibliothèques */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

/* Déclarations des fonctions et des macros */
/* quo_rem :
 * Entree :
 * Sortie :
 * AE :
 * AS :
 */
 void quo_rem (int a, int b, int *q, int *r) ;

/* Fonction principale */

int main(void) {
	int a, b;
	int q ;
	int r;
	printf("Saisissez deux entiers naturels (positifs ou nuls) : \n") ;
	do {
	if(scanf("%d %d", &a, &b) != 2) {
		return EXIT_FAILURE;
	 }
	 printf("Erreur ! vous devez saisir deux entiers naturels (positifs ou nuls). Recommencez\n");
	} while (a < 0 || b < 0) ;
	quo_rem (a, b, &q, &r) ;
  return EXIT_SUCCESS;
}

/* Définitions des fonctions */
 void quo_rem (int a, int b, int *q, int *r) {
   *q = 0;
   *r = a;
   printf ("a = %d, b = %d, q = %d\n", a, b, *q) ;
	 while (a >= b) {
      a = a - b;
     *q = *q + 1 ;
		 *r = a ;
		 printf ("a = %d, b = %d, q = %d\n", a, b, *q) ;
	}


}
