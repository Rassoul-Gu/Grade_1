/* [Nom du programme]
 * [Date de Création]
 * [Auteur(s)/Auteure(s)]
 * [Descriptif du programme ]
 */


/* Appel des bibliothèques */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

/* Déclarations des fonctions et des macros */
int nb_digits (int n) ;

/* Fonction principale */

int main(void) {
	//printf("%*d", 10, 10); decale de 10 avant d'ecrire 10
	int n;
	do {
		printf ("Entrez un entier compris entre 1 et 120 : \n");
	    if(scanf("%d", &n) != 1) {
        printf("Erreur de saisie\n");
		  return EXIT_FAILURE;
	    }

	 } while (n < 1 || n > 120) ;

	int k = 1;
	while (k <= n) {
		printf("%d\n", k);
		for (int i = 0; i < k; ++i) {
			printf(" ");
		}
		++k;

	}

  return EXIT_SUCCESS;
}

/* Définitions des fonctions */
/*
 * int nb_digits (int n) {
 * int nb = 1 ;
 * while (n >= 10 ou n <= -1) {
 * nb += 1 ;
 *
 * n = n /10 ;
 * }
 * return nb ;
 */

