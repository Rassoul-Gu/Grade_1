/* [Nom du programme]
 * [Date de Création]
 * [Auteur(s)/Auteure(s)]
 * [Descriptif du programme ]
 */
 /* Commentaires Tp7 (max && gen_numbers) :
  * ./gen_numbers > toto (ou notes.txt)
  * ./max < toto (ou notes.txt) == lecture
  * ./max < toto (ou notes.txt) == affiche max
  */


/* Appel des bibliothèques */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#define M 21


/* Déclarations des fonctions et des macros */

int max (void) ;
/* Fonction principale */

int main(void) {

  printf("Le max est %d\n", max());

  return EXIT_SUCCESS;
}

/* Définitions des fonctions */
int max (void) {
   int k,m ;
   char c;

   assert(scanf("%d %c", &m, &c) == 2);

   while (scanf("%d %c", &k, &c) == 2) {
     if (m<k) m=k;
	}

  return m;
}

// non fini .
