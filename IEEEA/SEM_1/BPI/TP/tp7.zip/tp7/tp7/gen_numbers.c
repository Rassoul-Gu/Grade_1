/* [Nom du programme]
 * [Date de Création]
 * [Auteur(s)/Auteure(s)]
 * [Descriptif du programme ]
 */
 /* Commentaires Tp7 (max && gen_numbers) :
  * srand ((unsigned int)time(NULL)) == affiche aleatoire
  * ./gen_numbers > toto (ou notes.txt)
  * ./max < toto (ou notes.txt) == lecture
  * ./max < toto (ou notes.txt) == affiche max
  */

/* Appel des bibliothèques */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <time.h>

#define M 21

/* Déclarations des fonctions et des macros */

void gen_numbers (int n) ;

/* Fonction principale */

int main(void) {
	int n ;
  srand((unsigned int)time(NULL));
	if (scanf("%d", &n) != 1) {
		return EXIT_FAILURE;
	}
	gen_numbers (n) ;
  return EXIT_SUCCESS;
}

/* Définitions des fonctions */

void gen_numbers (int n) {

   assert(n > 0) ;


   int k = 0 ;
   int m ;
   while (k < n) {
	   ++ k;
	  m = rand() % M ;
	   printf (" %d | ", m);
	}

}
