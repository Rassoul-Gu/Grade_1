/* [Nom du programme]
 * [Date de Création]
 * [Auteur(s)/Auteure(s)]
 * [Descriptif du programme ]
 */
 

/* Appel des bibliothèques */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

/* Déclarations des fonctions et des macros */
/* invers : 
 * Entree :
 * Sortie :
 * AE :
 * AS : 
 * IB :
 */
void invers (int n) ;

/* Fonction principale */

int main(void) {
	int n ; 
	if(scanf("%d", &n) != 1) {
		return EXIT_FAILURE ;
	}
	invers(n) ;
  return EXIT_SUCCESS; 
}

/* Définitions des fonctions */

void invers (int n) {
	assert (n > 0) ;
	int k ;
	while (n!= 0) {
		k = n % 10 ;
		printf("%d", k) ;
		n /= 10 ;
	}
	printf("\n") ;

}
