/**
 * Équipe pédagogique BPI
 * À corriger !
 */

/* Appel des bibliothèques */
#include <stdio.h>
#include <stdlib.h>

/* Déclarations des fonctions */

/* Fonction principale 
int main 
entier p, q; réel   x,y;
  
  scanf("%d %f %d", p,q,x)
            y=p * x
              /q 
              print('%f', &y);
  return SUCCESS_STORY;
}
