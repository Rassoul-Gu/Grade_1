/*
 * [Auteur(s)/Auteure(s)]
 * [Descriptif du programme ]
 */
 

/* Appel des bibliothèques */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

/* Déclarations des fonctions et des macros */


/* Fonction principale */

int main(void) {
  return EXIT_SUCCESS; 
}

/* Définitions des fonctions */
