/*
 * Équipe pédagogique BPI
 * Affiche un message de bienvenue.
 */

/* Appel des bibliothèques */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

/* Déclarations des fonctions */

/* Fonction principale */

int main(void) {
  printf("Bienvenue en L1.\n");

  return EXIT_SUCCESS;
}

/* Définitions des fonctions */
