#include <stddef.h>
#include <assert.h>

#include "ue.h"

// Écrire ici les définitions des différentes fonctions demandées pour le TP
