/**
 * Équipe pédagogique BPI
 * Un premier programme qui dit bonjour (ou plutôt au revoir)
 */

#include <stdlib.h>
#include <stdio.h>

int main(void) {
    printf("Goobye cruel world.\n");
    return EXIT_SUCCESS;
}
