#include <stdlib.h>
#include "y1.h"
#include "y2.h"

int main() {
  y1();
  y2();
  return EXIT_SUCCESS;
}
