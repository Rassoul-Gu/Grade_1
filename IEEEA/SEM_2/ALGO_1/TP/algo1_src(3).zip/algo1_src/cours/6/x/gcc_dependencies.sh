#!/bin/bash
PS4='$ '
set -x
gcc -MM *.c
