#include "y1.h"
#include "z.h"

static void y() {
  z(1);
}

void y1() {
  y();
}
