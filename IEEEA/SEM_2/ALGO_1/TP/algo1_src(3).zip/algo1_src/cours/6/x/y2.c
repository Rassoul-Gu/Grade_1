#include "y2.h"
#include "z.h"

static void y() {
  z(2);
}

void y2() {
  y();
}
