#ifndef Z__H
#define Z__H

extern void z(int n);

#endif
