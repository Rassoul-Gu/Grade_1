#ifndef Y1__H
#define Y1__H

extern void y1();

#endif
