#ifndef Y2__H
#define Y2__H

extern void y2();

#endif
